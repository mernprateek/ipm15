import React from 'react'

const Feauture2 = () => {
  return (
    <div></div>
  )
}

export default Feauture2